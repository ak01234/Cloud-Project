from flask import Flask, render_template, request
app = Flask(__name__, template_folder='templates')
import yfinance as yf
import matplotlib.pyplot as plt
import plotly.graph_objects as go

@app.route("/")
def home():
  return render_template('test.html')

list = []
@app.route("/", methods = ['GET','POST'])
def getvalue():
  if request.method == 'POST':
    name = request.form.get("Name")
    print(name)
    list.append(name)
    sdate = request.form.get("SDate")
    list.append(sdate) 
    edate = request.form.get("EDate")
    EDate = edate
    list.append(EDate)
    print(sdate, edate)
    # Set the start and end date
    start_date = sdate
    end_date = edate

    # Set the ticker
    ticker = name

    print(ticker,start_date, end_date)
    # Get the data
    data = yf.download(ticker, start_date, end_date)

    data['Adj Close'].plot()
    plt.show()

    fig = go.Figure(
    data=go.Ohlc(
        x=data.index,
        open=data["Open"],
        high=data["High"],
        low=data["Low"],
        close=data["Close"],
    )
)
    fig.show()
    




app.run()



